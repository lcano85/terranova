<?php
require_once __DIR__ . '/../core/Helpers.php';
require_once __DIR__ . '/../core/Csrf.php';
require_once __DIR__ . '/../core/Auth.php';
require_once __DIR__ . '/../core/Controller.php';
require_once __DIR__ . '/../core/Database.php';

class App {
  public function run(): void {
    $path = parse_url($_SERVER['REQUEST_URI'] ?? '/', PHP_URL_PATH);
    $path = rtrim($path, '/') ?: '/';

    $routes = [
      '/' => ['AuthController', 'login'],
      '/login' => ['AuthController', 'login'],
      '/logout' => ['AuthController', 'logout'],

      '/attendance/mark' => ['AttendanceController', 'mark'],
      '/tasks/board' => ['TasksController', 'board'],
      '/concurso/cena' => ['LeadDinnerController', 'form'],
      '/concurso/cena/gracias' => ['LeadDinnerController', 'thankYou'],

      '/admin' => ['AdminController', 'dashboard'],
      '/admin/workers' => ['AdminController', 'workers'],
      '/admin/shifts' => ['AdminController', 'shifts'],
      '/admin/areas' => ['AdminController', 'areas'],
      '/admin/purchase-areas' => ['AdminController', 'purchaseAreas'],
      '/admin/requirements' => ['AdminController', 'requirements'],
      '/admin/activities' => ['AdminController', 'activities'],
      '/admin/tasks' => ['AdminController', 'tasks'],
      '/admin/promotions' => ['AdminController', 'promotions'],
      '/admin/attendance' => ['AdminController', 'attendance'],
      '/admin/payroll' => ['AdminController', 'payroll'],
      '/admin/inventory' => ['AdminController', 'inventory'],
      '/admin/products' => ['AdminController', 'products'],
      '/admin/costing' => ['AdminController', 'costing'],
      '/admin/recipes' => ['AdminController', 'recipes'],
      '/admin/sales' => ['AdminController', 'sales'],
      '/admin/leads-cena' => ['AdminController', 'leadDinnerEntries'],
      '/admin/leads-cena-statuses' => ['AdminController', 'leadDinnerStatuses'],
      '/admin/profile' => ['AdminController', 'profile'],

      // Público: ver promoción del día (para la pantalla de marcación)
      '/promotions/today' => ['PromotionsController', 'today'],
      '/promotions/weekly' => ['PromotionsController', 'weekly'],

      '/worker' => ['WorkerController', 'dashboard'],
      '/worker/attendance' => ['WorkerController', 'myAttendance'],
      '/worker/payments' => ['WorkerController', 'payments'],
      '/worker/inventory' => ['WorkerController', 'inventory'],
      '/worker/requirements' => ['WorkerController', 'requirements'],
      '/worker/activities' => ['WorkerController', 'activities'],
      '/worker/tasks' => ['WorkerController', 'tasks'],
      '/worker/recipes' => ['WorkerController', 'recipes'],
      '/worker/profile' => ['WorkerController', 'profile'],
    ];

    if (!isset($routes[$path])) {
      http_response_code(404);
      echo "404 - Ruta no encontrada";
      return;
    }

    [$controller, $method] = $routes[$path];

    require_once __DIR__ . '/../controllers/' . $controller . '.php';
    $instance = new $controller();

    if (!method_exists($instance, $method)) {
      http_response_code(500);
      echo "500 - Método no existe";
      return;
    }

    $instance->$method();
  }
}
